//
//  Interactor.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 27/06/22.
//

import Foundation

class Interactor: InteractorInputProtocol {

    
    weak var presenter: InteractorOutputProtocol?
    var localDatamanager: LocalDataManagerInputProtocol?
    var remoteDatamanager: RemoteDataManagerInputProtocol?
    
    func retrievePostList() {
        do {
           /* if let postList = try localDatamanager?.retrievePostList() {
                let postModelList = postList.map() {
                    /*return PruevaModel(id: Int($0.id), title: $0.title!, imageUrl: $0.imageUrl!, thumbImageUrl: $0.thumbImageUrl!)*/
                }
                if  postModelList.isEmpty {
                    remoteDatamanager?.retrievePostList()
                }else{
                   presenter?.didRetrievePosts(postModelList)
                }
            } else {
                remoteDatamanager?.retrievePostList()
            }*/
            
        } catch {
            presenter?.didRetrievePosts([])
        }
    }
    
    
    //metodo que se encarga de subir la imagen al servidor
    func sengImagen(urlFile: URL, nameFile: String) {
        remoteDatamanager?.sengImagen(urlFile: urlFile, nameFile: nameFile)
    }
        
}

extension Interactor: RemoteDataManagerOutputProtocol {
    func onSuccess(message: String) {
        presenter?.onSuccess(message: message)
    }
    
    func onError(message: String) {
        presenter?.onError(message: message)
    }
    
    
    func onPostsRetrieved(_ posts: [PruevaModel]) {
        presenter?.didRetrievePosts(posts)
        
        for postModel in posts {
            do {
               /* try localDatamanager?.savePost(id: postModel.id, title: postModel., imageUrl: postModel.imageUrl, thumbImageUrl: postModel.thumbImageUrl)*/
            } catch  {
                
            }
        }
    }
    

    
}
