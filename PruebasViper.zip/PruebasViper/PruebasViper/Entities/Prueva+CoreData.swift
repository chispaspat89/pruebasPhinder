//
//  Prueva+CoreData.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 27/06/22.
//


import Foundation
import CoreData


extension Prueva {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Prueva> {
        return NSFetchRequest<Prueva>(entityName: "Prueva");
    }

    @NSManaged public var color: String?
    @NSManaged public var sexo: String?
    @NSManaged public var fecha: String?
    @NSManaged public var numero: String?
    @NSManaged public var nombre: String?
    @NSManaged public var id: Int32

}
