//
//  PruevaModel.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 27/06/22.
//

import Foundation
import ObjectMapper

struct PruevaModel {
    var id = 0
    var nombre = ""
    var numero = ""
    var fecha = ""
    var sexo = ""
    var color = ""
}

extension PruevaModel: Mappable {
    
    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        id       <- map["id"]
        nombre     <- map["nombre"]
        numero     <- map["numero"]
        fecha     <- map["fecha"]
        sexo     <- map["sexo"]
        color     <- map["color"]
    }
    
}
