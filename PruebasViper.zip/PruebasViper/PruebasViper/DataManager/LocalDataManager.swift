//
//  LocalDataManager.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 27/06/22.
//

import Foundation

import CoreData

class LocalDataManager:LocalDataManagerInputProtocol {
    
    func retrievePostList() throws -> [Prueva]  {
        
        guard let managedOC = CoreDataStore.managedObjectContext else {
            throw PersistenceError.managedObjectContextNotFound
        }
        
        let request: NSFetchRequest<Prueva> = NSFetchRequest(entityName: String(describing: Prueva.self))
        
        return try managedOC.fetch(request)
    }
    
    func savePost(id: Int, title: String, imageUrl: String, thumbImageUrl: String) throws {
        guard let managedOC = CoreDataStore.managedObjectContext else {
            throw PersistenceError.managedObjectContextNotFound
        }
        
        if let newPost = NSEntityDescription.entity(forEntityName: "Prueva",
                                                           in: managedOC) {
            let post = Prueva(entity: newPost, insertInto: managedOC)
            post.id = Int32(id)
            
           
            
            try managedOC.save()
        }
        throw PersistenceError.couldNotSaveObject
    
    }
    
}
