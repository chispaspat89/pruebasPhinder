//
//  Prueva.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 27/06/22.
//


import Foundation
import CoreData


public class Prueva: NSManagedObject {
    
}
