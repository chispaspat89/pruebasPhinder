//
//  PruebasViewController.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 28/06/22.
//

import UIKit

class PruebasViewController: UITableViewController, UITextFieldDelegate {

     var delegate : ViewProtocol?
   
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          tableView.deselectRow(at: indexPath, animated: true)
        
        

          if(indexPath.row == 1){
              delegate!.openCamara()
          }
        
        if(indexPath.row == 3){
           // delegate!.sengImagen()
            var data = ""
         
            let index = IndexPath(row: 0, section: 0)
            let cell = tableView.cellForRow(at: index)
        
            if let txtField1 = cell!.viewWithTag(1) as? UITextField {
                
               
                delegate?.sengImagen(nameFile: txtField1.text!)
            }
            
         
        }
            
      }
    
    
   
    
  
}

