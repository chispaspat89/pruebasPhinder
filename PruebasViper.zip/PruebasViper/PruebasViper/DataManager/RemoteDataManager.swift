//
//  RemoteDataManager.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 29/06/22.
//

import Foundation
import Alamofire
import AlamofireObjectMapper
import FirebaseStorage

class RemoteDataManager:RemoteDataManagerInputProtocol {
  
    
    var remoteRequestHandler: RemoteDataManagerOutputProtocol?
    
    //metodo que se encarga de obtener el api que tenian definido
    func retrievePostList() {
        Alamofire
            .request(Endpoints.Posts.fetch.url, method: .get)
            .validate()
            .responseArray(completionHandler: { (response: DataResponse<[PruevaModel]>) in
                switch response.result {
                case .success(let posts):
                    self.remoteRequestHandler?.onPostsRetrieved(posts)
            
                case .failure( _):
                    self.remoteRequestHandler?.onError(message: "Se produjo un error al obtener la informacion en el servidor")
                }
            })
    }
    
    //metodo que envia la imagen a cloud de google
    func sengImagen(urlFile: URL, nameFile: String) {
        
        
        print("subiendoiMAGEN")
        print(nameFile)
        print(urlFile.pathExtension)
             do {
                 // Create file name
                 let fileExtension = urlFile.pathExtension
                 let fileName = "images/\(nameFile).\(fileExtension)"

                 let metaData = StorageMetadata()
                 let storageReference = Storage.storage().reference().child(fileName)
                 let currentUploadTask = storageReference.putFile(from: urlFile, metadata: nil) { (storageMetaData, error) in
                   if let error = error {
                     print("Upload error: \(error.localizedDescription)")
                     return
                   }
                                                                                             
                   // Show UIAlertController here
                   print("Image file: \(fileName) is uploaded! View it at Firebase console!")
                     
                     
                                                                                             
                     storageReference.downloadURL { [self] (url, error) in
                     if let error = error  {
                       print("Error on getting download url: \(error.localizedDescription)")
                         //self.showAlertWith(title: "Error Upload Image", message: error.localizedDescription)
                         self.remoteRequestHandler?.onError(message: error.localizedDescription)
                       return
                     }
                       print("Download url of \(fileName) is \(url!.absoluteString)")
                       
                         //self.showAlertWith(title: "Upload Image", message: "Download url of \(fileName) is \(url!.absoluteString)")
                         self.remoteRequestHandler?.onSuccess(message: "Download url of \(fileName) is \(url!.absoluteString)")
                   }
                 }
               } catch {
                   print("Error on extracting data from url: \(error.localizedDescription)")
                   
                   //showAlertWith(title: "Error Upload Image", message: error.localizedDescription)
                   self.remoteRequestHandler?.onError(message: error.localizedDescription)
               }
    }
    
    
}
