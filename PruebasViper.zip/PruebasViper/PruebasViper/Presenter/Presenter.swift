//
//  Presenter.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 27/06/22.
//

import Foundation

class Presenter: PresenterProtocol {
    
   

    
    weak var view: ViewProtocol?
    var interactor: InteractorInputProtocol?
  
    
    func viewDidLoad() {

        interactor?.retrievePostList()
    }
    
    func showPostDetail(forPost post: PruevaModel) {
        
    }
    
    func sengImagen(urlFile: URL, nameFile: String) {
        print("entrando al presenter")
        interactor?.sengImagen(urlFile: urlFile, nameFile: nameFile)
    }
    

}

extension Presenter: InteractorOutputProtocol {
    func onSuccess(message: String) {
        view?.onSuccess(message: message)
    }
    
    func onError(message: String) {
        view?.onError(message: message)
    }
    
    
    func didRetrievePosts(_ posts: [PruevaModel]) {
    
   
    }
    
   
}


