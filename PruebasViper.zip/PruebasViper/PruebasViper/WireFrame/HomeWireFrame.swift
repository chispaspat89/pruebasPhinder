//
//  HomeWireFrame.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 29/06/22.
//
import UIKit

class HomeWireFrame: PresenterToRouterPostsListProtocol {
    
    static func createPostsListModule(postsListRef: ViewController) {
       
        print("Routing")
        let presenter: PresenterProtocol & InteractorOutputProtocol = Presenter()
        let interactor: InteractorInputProtocol & RemoteDataManagerOutputProtocol = Interactor()
        let localDataManager: LocalDataManagerInputProtocol = LocalDataManager()
        let remoteDataManager: RemoteDataManagerInputProtocol = RemoteDataManager()
        
        
        postsListRef.presenter =  presenter
        postsListRef.presenter?.view = postsListRef
        postsListRef.presenter?.interactor = interactor
        interactor.presenter = presenter
        interactor.localDatamanager = localDataManager
        interactor.remoteDatamanager = remoteDataManager
        remoteDataManager.remoteRequestHandler = interactor
        
        
        
        
        
        
    }
    
  
    func presentPostDetailScreen(from view: ViewProtocol, forPost post: PruevaModel) {
        
    }
    
    
    /*class func createPostListModule() -> UIViewController {
        let navController = mainStoryboard.instantiateViewController(withIdentifier: "pruebas")
        
        if let view = navController.children.first as? ViewController {
            let presenter: PresenterProtocol & InteractorOutputProtocol = Presenter()
            let interactor: InteractorInputProtocol & RemoteDataManagerOutputProtocol = Interactor()
            let localDataManager: LocalDataManagerInputProtocol = LocalDataManager()
            let remoteDataManager: RemoteDataManagerInputProtocol = RemoteDataManager()
            let wireFrame: WireFrameProtocol = HomeWireFrame()
            
            view.presenter = presenter
            presenter.view = view
            presenter.wireFrame = wireFrame
            presenter.interactor = interactor
            interactor.presenter = presenter
            interactor.localDatamanager = localDataManager
            interactor.remoteDatamanager = remoteDataManager
            remoteDataManager.remoteRequestHandler = interactor
            
            print("**************************1234567890")
            return navController
        }
        
        return UIViewController()
    }
    
    static var mainStoryboard: UIStoryboard {
        return UIStoryboard(name: "Main", bundle: Bundle.main)
    }*/
    

 
}
