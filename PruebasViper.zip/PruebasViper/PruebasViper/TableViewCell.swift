//
//  TableViewCell.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 28/06/22.
//

import Foundation
import SwiftUI

class PostTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var name: TextField!
    
    func set(forPost post: Post) {
        self.selectionStyle = .none
        titleLabel?.text = post.title
        let url = URL(string: post.thumbImageUrl)!
        let placeholderImage = UIImage(named: "placeholder")!
        postImageView?.af_setImage(withURL: url, placeholderImage: placeholderImage)
    }
}
