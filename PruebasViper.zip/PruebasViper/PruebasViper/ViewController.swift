//
//  ViewController.swift
//  PruebasViper
//


import UIKit
import PKHUD
import FirebaseStorage
import MobileCoreServices

class ViewController: UIViewController, UINavigationControllerDelegate  {
 
    @IBOutlet weak var tablePruebas: UITableView!
   
    var imagePicker: UIImagePickerController!
    var presenter: PresenterProtocol?
    var List: [PruevaModel] = []
    var urlmagenSeleccionada: URL?
    
    enum ImageSource {
        case photoLibrary
        case camera
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        HomeWireFrame.createPostsListModule(postsListRef: self)
      
    }

    //@IBOutlet weak var table: UIView!
    
    @IBAction func btnSubirImagen(_ sender: Any) {
        
        let index = IndexPath(row: 0, section: 0)
        let cell = tablePruebas.cellForRow(at: index)
    
        if let txtField1 = cell!.viewWithTag(1) as? UITextField {
     
            var nombre = txtField1.text!
            if(nombre.elementsEqual("")){
                print("debes de ingresar el nombre del archivo")
            }else{
                print("subir archivo")
                presenter?.sengImagen(urlFile: (self.urlmagenSeleccionada)!, nameFile: nombre)

            }
        
        }
        
       // presenter?.sengImagen(urlFile: (self.urlmagenSeleccionada)!, nameFile: nameFile)
    }
}

extension ViewController : ViewProtocol, UIImagePickerControllerDelegate {
  
    func onSuccess(message: String) {
        showAlertWith(title: "Guardado!", message: message)
    }
    
    func onError(message: String) {
        showAlertWith(title: "Error!", message: message)
    }
    
    func sengImagen(nameFile:String) {
        print("presionado")
        presenter?.sengImagen(urlFile: (self.urlmagenSeleccionada)!, nameFile: nameFile)
        
    }
    
    func getDatos(with posts: [PruevaModel]) {
        List = posts
    }
    

    
    func showError() {
        HUD.flash(.label("Internet not connected"), delay: 2.0)
    }
    
    func showLoading() {
        HUD.show(.progress)
    }
    
    func hideLoading() {
        HUD.hide()
    }
    
    func openCamara() {
        print("")
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
                   selectImageFrom(.photoLibrary)
                   return
               }
               selectImageFrom(.camera)
    }
    
  
    
    func selectImageFrom(_ source: ImageSource){
        
      
        
           imagePicker =  UIImagePickerController()
   
           imagePicker.delegate = self
           switch source {
           case .camera:
               imagePicker.sourceType = .camera
           case .photoLibrary:
               imagePicker.sourceType = .photoLibrary
           }
           present(imagePicker, animated: true, completion: nil)
    }
    
    //MARK: - Add image to Library
       @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
           if let error = error {
               // we got back an error!
               showAlertWith(title: "Error al guardar la imagen", message: error.localizedDescription)
           } else {
               showAlertWith(title: "Guardado!", message: "Your image has been saved to your photos.")
           }
       }

       func showAlertWith(title: String, message: String){
           let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
           ac.addAction(UIAlertAction(title: "OK", style: .default))
           present(ac, animated: true)
       }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        let mediaType = info[UIImagePickerController.InfoKey.mediaType] as! CFString
           if mediaType == kUTTypeImage {
             let imageURL = info[UIImagePickerController.InfoKey.imageURL] as! URL
             // Handle your logic here, e.g. uploading file to Cloud Storage for Firebase
               self.urlmagenSeleccionada =  imageURL
           }
            
        imagePicker.dismiss(animated: true, completion: nil)
           //imageTake.image = selectedImage
       }
}



extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
                return tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        }
        else if indexPath.row == 1 {
                return tableView.dequeueReusableCell(withIdentifier: "Cell2", for: indexPath)
        }
        else {
                return tableView.dequeueReusableCell(withIdentifier: "Cell3", for: indexPath)
        }
    }
     func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
        
        if(indexPath.row == 1){
            guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
                       selectImageFrom(.photoLibrary)
                       return
                   }
                   selectImageFrom(.camera)
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if(indexPath.row == 0){
           return 80
        }else if( indexPath.row == 1){
            return 50
        }else{
            return 380
        }
                    
       // return 50
    }
    
}
