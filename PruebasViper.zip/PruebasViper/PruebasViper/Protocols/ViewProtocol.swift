//
//  ViewProtocol.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 27/06/22.
//

import Foundation

import UIKit

protocol ViewProtocol: class {
    var presenter: PresenterProtocol? { get set }
    

    func showError()
    
    func showLoading()
    
    func hideLoading()
    
    func openCamara()
    func sengImagen(nameFile:String)
    
    
    // PRESENTER -> VIEW
    func getDatos(with posts: [PruevaModel])
    
    func onSuccess(message:String)
    func onError(message:String)
    
    
}



protocol PresenterProtocol: class {
    var view: ViewProtocol? { get set }
    var interactor: InteractorInputProtocol? { get set }

    
    // VIEW -> PRESENTER
    func viewDidLoad()
    func showPostDetail(forPost post: PruevaModel)
    func sengImagen(urlFile:URL, nameFile: String)
}

protocol InteractorOutputProtocol: class {
    // INTERACTOR -> PRESENTER
    func didRetrievePosts(_ posts: [PruevaModel])
    func onSuccess(message:String)
    func onError(message:String)
}

protocol InteractorInputProtocol: class {
    var presenter: InteractorOutputProtocol? { get set }
    var localDatamanager: LocalDataManagerInputProtocol? { get set }
    var remoteDatamanager: RemoteDataManagerInputProtocol? { get set }
    
    // PRESENTER -> INTERACTOR
    func retrievePostList()
    func sengImagen(urlFile:URL, nameFile: String)
}

protocol DataManagerInputProtocol: class {
    // INTERACTOR -> DATAMANAGER
}

protocol RemoteDataManagerInputProtocol: AnyObject {
    var remoteRequestHandler: RemoteDataManagerOutputProtocol? { get set }
    
    // INTERACTOR -> REMOTEDATAMANAGER
    func retrievePostList()
    func sengImagen(urlFile:URL, nameFile: String)
}

protocol RemoteDataManagerOutputProtocol: AnyObject {
    // REMOTEDATAMANAGER -> INTERACTOR
    func onPostsRetrieved(_ posts: [PruevaModel])
    func onSuccess(message:String)
    func onError(message:String)
}

protocol LocalDataManagerInputProtocol: class {
     // INTERACTOR -> LOCALDATAMANAGER
    func retrievePostList() throws -> [Prueva]
    func savePost(id: Int, title: String, imageUrl: String, thumbImageUrl: String) throws
}





protocol PresenterToRouterPostsListProtocol:class {
    
    static func createPostsListModule(postsListRef: ViewController)
    
}
