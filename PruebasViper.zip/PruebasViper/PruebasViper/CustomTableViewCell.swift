//
//  CustomTableViewCell.swift
//  PruebasViper
//
//  Created by Roberto Gameros on 29/06/22.
//

import Foundation
import UIKit

public class CustomTableViewCell: UITableViewCell{

    @IBOutlet weak var textField: UITextField!
    
    public func configure(texto: String?, placeholder: String) {
        textField.text = texto
        textField.placeholder = placeholder

        textField.accessibilityValue = texto
        textField.accessibilityLabel = placeholder
    }
}
